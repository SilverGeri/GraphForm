﻿using System.Collections.Generic;

namespace GraphForm.Model
{
    using GraphType = List<List<Edge>>;
    public abstract class GraphAlgorythmBase
    {
        protected GraphType _graph;

        public GraphAlgorythmBase(ref GraphType graph)
        {
            _graph = graph;
        }
        public abstract void Init();
        public abstract void Next();
        public abstract bool End();

        public void Finish()
        {
            while (!End())
            {
                Next();
            }
        }
    }
}