﻿using System;
using System.Collections.Generic;

namespace GraphForm.Model   
{
    public delegate void NodeEventHandler(object source, NodeEventArgs e);
    public delegate void EdgeEventHandler(object source, EdgeEventArgs e);
    public delegate void MessageEventHandler(object source, MessageEventArgs e);
    public class NodeEventArgs : EventArgs
    {
        public string Text { get; private set; }

        public NodeEventArgs(string text)
        {
            Text = text;
        }
    }

    public class EdgeEventArgs : EventArgs
    {
        public int StartNode { get; private set; }
        public int EndNode { get; private set; }
        public double Weight { get; private set; }

        public EdgeEventArgs(int startNode, int endNode, double weight)
        {
            Weight = weight;
            EndNode = endNode;
            StartNode = startNode;
        }
    }

    public class MessageEventArgs : EventArgs
    {
        public MessageEventArgs(string message, string caption)
        {
            Message = message;
            Caption = caption;
        }

        public string Message { get; private set; }
        public string Caption { get; private set; }
    }

    class GraphModel
    {
        public bool IsDirected { get; private set; }
        public event NodeEventHandler AddNodeEvent;
        public event EdgeEventHandler AddEdgeEvent;
        public event MessageEventHandler NotifyEvent;
        private List<List<Edge>> graphList;
        private GraphAlgorythmBase algorythm;
        private int _id;
        public GraphModel(bool isDirected)
        {
            _id = 1;
            IsDirected = isDirected;
            graphList = new List<List<Edge>>();
        }

        public void AddNode()
        {
            AddNodeEvent(this, new NodeEventArgs(_id.ToString()));
            graphList.Add(new List<Edge>());
            
            ++_id;
        }

        public void AddEdge(int startNode, int endNode, double weight)
        {
            string error = "";
            if (startNode < 1 || startNode > graphList.Count)
            {
                error += "Érvénytelen kezdőcsúcs\n";
            }

            if (endNode < 1 || endNode > graphList.Count)
            {
                error += "Érvénytelen végcsúcs\n";
            }

            if (error != "")
            {
                NotifyEvent(this, new MessageEventArgs(error, "Hiba"));
            }
            else
            {
                graphList[startNode - 1].Add(new Edge(endNode-1, weight));
                if (!IsDirected)
                {
                    graphList[endNode - 1].Add(new Edge(startNode-1, weight));
                }
                AddEdgeEvent(this, new EdgeEventArgs(startNode, endNode, weight));
            }
        }
    }
}
