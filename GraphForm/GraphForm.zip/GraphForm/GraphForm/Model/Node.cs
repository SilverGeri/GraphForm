﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphForm.Model
{
    public enum State { White, Gray, Black }

    class Node
    {
        public State State { get; set; }
    }
}
