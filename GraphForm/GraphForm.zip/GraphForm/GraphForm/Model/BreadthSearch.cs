﻿using System;
using System.Collections.Generic;

namespace GraphForm.Model
{
    public class myEventArgs : EventArgs
    {
        public string x { get; set; }

        public myEventArgs(string x_)
        {
            x = x_;
        }
    }

    public delegate void myEventHandler(object sender, myEventArgs e);

    class BreadthSearch : GraphAlgorythmBase
    {
        public event myEventHandler test;
        public BreadthSearch(ref List<List<Edge>> graph) : base(ref graph)
        {
            graph.Add(new List<Edge>());
            
        }
        public override void Init()
        {
            //throw new NotImplementedException();
            test(this, new myEventArgs("ghs"));
        }

        public override void Next()
        {
            throw new NotImplementedException();
        }

        public override bool End()
        {
            throw new NotImplementedException();
        }
    }
}
