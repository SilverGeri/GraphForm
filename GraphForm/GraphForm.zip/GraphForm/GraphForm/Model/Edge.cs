﻿namespace GraphForm.Model
{
    public class Edge
    {
        public Edge(int end, double weight)
        {
            End = end;
            Weight = weight;
        }

        public int End { get; private set; }
        public double Weight { get; private set; }
    }
}
