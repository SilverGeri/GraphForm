﻿namespace GraphForm.View
{
    public enum State { Visible, Invisible, Selected}
    class Edge
    {
        public Edge(int startNode,int endNode, double weight)
        {
            Weight = weight;
            StartNode = startNode;
            EndNode = endNode;
            State = State.Visible;
        }

        public int StartNode { get; private set; }
        public int EndNode { get; private set; }
        public double Weight { get; private set; }
        public State State { get; set; }
    }
}
