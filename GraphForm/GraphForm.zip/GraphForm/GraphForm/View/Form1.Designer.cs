﻿namespace GraphForm.View
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.addButton = new System.Windows.Forms.Button();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.újGráfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newUndirected = new System.Windows.Forms.ToolStripMenuItem();
            this.newDirected = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.linebtn = new System.Windows.Forms.Button();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.StartNodeBox = new System.Windows.Forms.TextBox();
            this.EndNodeBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.edgeWeightBox = new System.Windows.Forms.TextBox();
            this.algorythmChooser = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(90, 5);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 20);
            this.addButton.TabIndex = 0;
            this.addButton.Text = "Új csúcs";
            this.addButton.UseVisualStyleBackColor = true;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.újGráfToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1160, 24);
            this.menuStrip2.TabIndex = 2;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // újGráfToolStripMenuItem
            // 
            this.újGráfToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newUndirected,
            this.newDirected});
            this.újGráfToolStripMenuItem.Name = "újGráfToolStripMenuItem";
            this.újGráfToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.újGráfToolStripMenuItem.Text = "Új gráf";
            // 
            // newUndirected
            // 
            this.newUndirected.Name = "newUndirected";
            this.newUndirected.Size = new System.Drawing.Size(133, 22);
            this.newUndirected.Text = "Irányítatlan";
            // 
            // newDirected
            // 
            this.newDirected.Name = "newDirected";
            this.newDirected.Size = new System.Drawing.Size(133, 22);
            this.newDirected.Text = "Irányított";
            // 
            // linebtn
            // 
            this.linebtn.Location = new System.Drawing.Point(566, 5);
            this.linebtn.Name = "linebtn";
            this.linebtn.Size = new System.Drawing.Size(75, 20);
            this.linebtn.TabIndex = 3;
            this.linebtn.Text = "Hozzáad";
            this.linebtn.UseVisualStyleBackColor = true;
            // 
            // StartNodeBox
            // 
            this.StartNodeBox.Location = new System.Drawing.Point(297, 5);
            this.StartNodeBox.Name = "StartNodeBox";
            this.StartNodeBox.Size = new System.Drawing.Size(50, 20);
            this.StartNodeBox.TabIndex = 4;
            // 
            // EndNodeBox
            // 
            this.EndNodeBox.Location = new System.Drawing.Point(407, 5);
            this.EndNodeBox.Name = "EndNodeBox";
            this.EndNodeBox.Size = new System.Drawing.Size(50, 20);
            this.EndNodeBox.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(202, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Új él: Kezdőcsúcs:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(350, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Végcsúcs:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(468, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "élsúly:";
            // 
            // edgeWeightBox
            // 
            this.edgeWeightBox.Location = new System.Drawing.Point(500, 5);
            this.edgeWeightBox.Name = "edgeWeightBox";
            this.edgeWeightBox.Size = new System.Drawing.Size(50, 20);
            this.edgeWeightBox.TabIndex = 9;
            // 
            // algorythmChooser
            // 
            this.algorythmChooser.FormattingEnabled = true;
            this.algorythmChooser.Location = new System.Drawing.Point(657, 5);
            this.algorythmChooser.Name = "algorythmChooser";
            this.algorythmChooser.Size = new System.Drawing.Size(200, 21);
            this.algorythmChooser.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(874, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 20);
            this.button1.TabIndex = 11;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(977, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 20);
            this.button2.TabIndex = 12;
            this.button2.Text = "Következő";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1074, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(81, 20);
            this.button3.TabIndex = 13;
            this.button3.Text = "Végeredmény";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1160, 635);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.algorythmChooser);
            this.Controls.Add(this.edgeWeightBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.EndNodeBox);
            this.Controls.Add(this.StartNodeBox);
            this.Controls.Add(this.linebtn);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.menuStrip2);
            this.Name = "Form1";
            this.Text = "Gráfalgoritmusok";
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem újGráfToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newUndirected;
        private System.Windows.Forms.ToolStripMenuItem newDirected;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button linebtn;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.TextBox StartNodeBox;
        private System.Windows.Forms.TextBox EndNodeBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox edgeWeightBox;
        private System.Windows.Forms.ComboBox algorythmChooser;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}

