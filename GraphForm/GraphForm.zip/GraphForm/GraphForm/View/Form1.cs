﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;
using GraphForm.Model;

namespace GraphForm.View
{
    public partial class Form1 : Form
    {
        private GraphModel _model;
        private List<NodeView> nodes;
        private List<Edge> edges;
        private bool _isDragging;
        private Point _clickPosition;
        private Dictionary<int, string> algorythmDictionary;
        public Form1()
        {
            InitializeComponent();
            newUndirected.Click += NewGraph;
            newDirected.Click += NewGraph;
            addButton.Click += addNode;
            linebtn.Click += NewEdge;
            nodes = new List<NodeView>();
            edges = new List<Edge>();
            newUndirected.PerformClick();
            algorythmDictionary = new Dictionary<int, string>
            {
                {0, "Válassz egy algoritmust"},
                {1, "Szélességi bejárás"}
            };
            algorythmChooser.DataSource = new BindingSource(algorythmDictionary, null);
            algorythmChooser.DisplayMember = "Value";
            algorythmChooser.ValueMember = "Key";
        }

        private void NewGraph(object sender, EventArgs e)
        {
            if (sender == newUndirected)
                _model = new GraphModel(false);
            else if (sender == newDirected)
                _model = new GraphModel(true);
            _model.AddNodeEvent += addNodeHandler;
            _model.AddEdgeEvent += addEdgeHandler;
            _model.NotifyEvent += notifyEventHandler;
            foreach (NodeView node in nodes)
            {
                Controls.Remove(node);
            }
            nodes.Clear();
            edges.Clear();
            Refresh();
        }

        private void NewEdge(object sender, EventArgs e)
        {
            string error = "";
            int startNode, endNode;
            double weight;
            if (!int.TryParse(StartNodeBox.Text, out startNode))
            {
                error += "Hibás kezdőcsúcs!\n";
            }
            if (!int.TryParse(EndNodeBox.Text, out endNode))
            {
                error += "Hibás végcsúcs!\n";
            }
            if (!double.TryParse(edgeWeightBox.Text, out weight))
            {
                error += "Hibás élsúly!";
            }
            if (error != "")
            {
                MessageBox.Show(error, "Hiba");
            }
            else
            {
                _model.AddEdge(startNode, endNode, weight);
            }
        }

        private void addNode(object sender, EventArgs e)
        {
            _model.AddNode();
        }

        private void addNodeHandler(object sender, NodeEventArgs e)
        {
            var node = new NodeView(text: e.Text)
            {
                Height = 50,
                Width = 50,
                Location = new Point(30, 30),
                BackColor = Color.Green
            };
            node.MouseDown += mouseDown;
            node.MouseMove += mouseMove;
            node.MouseUp += mouseUp;

            Controls.Add(node);
            nodes.Add(node);
        }

        private void addEdgeHandler(object sender, EdgeEventArgs e)
        {
            edges.Add(new Edge(e.StartNode, e.EndNode, e.Weight));
            Refresh();
        }

        private void notifyEventHandler(object sender, MessageEventArgs e)
        {
            MessageBox.Show(e.Message, e.Caption);
        }

        public override void Refresh()
        {
            base.Refresh();
            var graph = CreateGraphics();
            graph.SmoothingMode = SmoothingMode.HighQuality;
            var pen = new Pen(Color.Black, 4);
            if (_model.IsDirected)
            {
                pen.StartCap = LineCap.NoAnchor;
                pen.EndCap = LineCap.ArrowAnchor;
                foreach (Edge edge in edges)
                {
                    var c = new Point((nodes[edge.StartNode - 1].Location.X + nodes[edge.EndNode - 1].Location.X) / 2,
                        (nodes[edge.StartNode - 1].Location.Y + nodes[edge.EndNode - 1].Location.Y) / 2);

                    if (nodes[edge.StartNode - 1].Location.X < nodes[edge.EndNode - 1].Location.X)
                        c.X += 50;
                    else
                        c.X -= 75;

                    if (nodes[edge.StartNode - 1].Location.Y < nodes[edge.EndNode - 1].Location.Y)
                        c.Y += 50;
                    else
                        c.Y -= 75;

                    double size = Math.Sqrt(Math.Pow(c.X - nodes[edge.EndNode - 1].Location.X, 2) +
                        Math.Pow(c.Y - nodes[edge.EndNode - 1].Location.Y, 2));
                    double cos = (nodes[edge.EndNode - 1].Location.Y - c.Y) / size;
                    double sin = (nodes[edge.EndNode - 1].Location.X - c.X) / size;
                    double y = c.Y+25 + cos * (size - 15);
                    double x = c.X+25 + sin * (size - 15);
                    graph.DrawString(edge.Weight.ToString(), DefaultFont, new SolidBrush(Color.Red), c );

                    if (edge.State == State.Invisible)
                    {
                        continue;
                    }
                    else if (edge.State == State.Selected)
                    {
                        pen.Color = Color.Blue;
                    }
                    graph.DrawBezier(pen, new Point(nodes[edge.StartNode - 1].Location.X + 25, nodes[edge.StartNode - 1].Location.Y + 25), c, c,
                            new Point((int)x, (int)y));
                }
            }
            else
            {
                foreach (Edge edge in edges)
                {
                    var c = new Point((nodes[edge.StartNode - 1].Location.X + nodes[edge.EndNode - 1].Location.X) / 2 ,
                        (nodes[edge.StartNode - 1].Location.Y + nodes[edge.EndNode - 1].Location.Y) / 2);

                    graph.DrawString(edge.Weight.ToString(), DefaultFont, new SolidBrush(Color.Red), c);


                    if (edge.State == State.Invisible)
                    {
                        continue;
                    }
                    else if (edge.State == State.Selected)
                    {
                        pen.Color = Color.Blue;
                    }
                    graph.DrawLine(pen, new Point(nodes[edge.StartNode - 1].Location.X + 25, nodes[edge.StartNode - 1].Location.Y + 25),
                        new Point(nodes[edge.EndNode - 1].Location.X + 25, nodes[edge.EndNode - 1].Location.Y + 25));
                }
            }
        }

        public void mouseDown(object sender, MouseEventArgs e)
        {
            var draggable = sender as Control;
            if (draggable != null)
            {
                _isDragging = true;
                draggable.Capture = true;
                _clickPosition = e.Location;
            }
        }

        public void mouseMove(object sender, MouseEventArgs e)
        {
            var draggable = sender as Control;
            if (_isDragging && draggable != null)
            {
                var currentPosition = e.Location;
                draggable.Left += currentPosition.X - _clickPosition.X;
                draggable.Top += currentPosition.Y - _clickPosition.Y;
                Refresh();
            }
        }

        public void mouseUp(object sender, MouseEventArgs e)
        {
            var draggable = sender as Control;
            if (draggable != null)
            {
                _isDragging = false;
                draggable.Capture = false;
                Refresh();
            }
        }
    }
}
