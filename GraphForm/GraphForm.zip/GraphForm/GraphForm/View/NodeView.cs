﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraphForm.View
{
    public partial class NodeView : Button
    {
        public NodeView(string text)
        {
            Text = text;
        }

        public override sealed string Text
        {
            get { return base.Text; }
            set { base.Text = value; }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var buttonPath = new GraphicsPath();
            Rectangle newRectangle = ClientRectangle;
            newRectangle.Inflate(-10,-10);
            e.Graphics.DrawEllipse(Pens.Green, newRectangle);
            newRectangle.Inflate(1,1);
            buttonPath.AddEllipse(newRectangle);
            Region = new Region(buttonPath);
            base.OnPaint(e);
        }
    }
}
